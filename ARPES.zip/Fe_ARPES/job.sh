#!/bin/bash 
#SBATCH --partition=B2                # select partition (A1, A2, A3, A4, B1, B2, or B3) 
#SBATCH --time=24:00:00               # set time limit in HH:MM:SS 
#SBATCH --nodes=1                     # number of nodes 
#SBATCH --ntasks-per-node=48          # number of processes per node (for MPI) 
#SBATCH --cpus-per-task=1             # OMP_NUM_THREADS (for openMP) 
#SBATCH --job-name=mos                # job name #SBATCH --output="error.%x"
                                      # standard output and error are redirected to 
                                      # <job name>_<job ID>.out # for OpenMP jobs export
                                      # if srun -n not working, try mpirun -np
OMP_NUM_THREADS=${SLURM_CPUS_PER_TASK}
# load modules if needed

module load oneapi/mkl/2024.1
module load oneapi/mpi/2021.12
module load oneapi/oclfpga/2024.1.0
module load oneapi/compiler/2024.1.0

vasp=/ioss/ytqian/soft/vasp-wann1.2/bin/vasp_ncl

##kkrscf=/ioss/ytqian/soft/SPRKKR/SPRKKR-7.7/bin/kkrscf7.7.0
kkrscf=/ioss/ytqian/soft/SPRKKR/SPRKKR-8.6/bin/kkrscf8.6
kkrgen=/ioss/ytqian/soft/SPRKKR/SPRKKR-8.6/bin/kkrgen8.6

#kkrspec=/ioss/ytqian/soft/SPRKKR/SPRKKR-8.6/bin/kkrspec8.6
kkrspec=/ioss/ytqian/soft/SPRKKR/SPRKKR-8.6debug/bin/kkrspec8.6debug

#SCF
#mpirun -np $SLURM_NTASKS $kkrscf Fe_SCF.inp > Fe_SCF.out
#mv Fe.pot_new Fe.pot

#BAND
#mpirun -np $SLURM_NTASKS $kkrgen Fe_EKREL.inp > Fe_EKREL.out

#DOS
#mpirun -np $SLURM_NTASKS $kkrgen Fe_DOS.inp > Fe_DOS.out

#spec
#mpirun -np $SLURM_NTASKS $kkrspec Fe_ARPES.inp > Fe_ARPES.out
#mpirun -np $SLURM_NTASKS $kkrspec Fe_AIPES.inp > Fe_AIPES.out
mpirun -np $SLURM_NTASKS $kkrspec Fe_BAND.inp > Fe_BAND.out

#mpirun -np 4 /ioss/ytqian/soft/SPRKKR-7.7/bin/kkrscf Al_SCF.inp > kkrscf.out
##mpirun -np $SLURM_NTASKS $kkrscf Al_DOS.inp > kkrdos.out
##mpirun -np $SLURM_NTASKS $kkrscf Al_SIGMA.inp > kkrsigma.out
